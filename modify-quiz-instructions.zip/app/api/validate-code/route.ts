import { sql } from '@vercel/postgres'

export async function POST(request: Request) {
  try {
    const { code } = await request.json()

    if (!code || typeof code !== 'string') {
      return Response.json(
        { error: 'Code is required' },
        { status: 400 }
      )
    }

    // Check if code exists and hasn't been used
    const result = await sql`
      SELECT id, is_used FROM codes WHERE code = ${code.trim()}
    `

    if (result.rows.length === 0) {
      return Response.json(
        { error: 'Code not found' },
        { status: 404 }
      )
    }

    const codeRecord = result.rows[0] as { id: number; is_used: boolean }

    if (codeRecord.is_used) {
      return Response.json(
        { error: 'This code has already been used' },
        { status: 403 }
      )
    }

    // Mark code as used
    await sql`
      UPDATE codes SET is_used = true WHERE id = ${codeRecord.id}
    `

    return Response.json({ success: true, message: 'Code validated successfully' })
  } catch (error) {
    console.error('Code validation error:', error)
    return Response.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

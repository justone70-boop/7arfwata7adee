import { WordChallengeGame } from '@/components/word-challenge-game'

export default function Page() {
  return (
    <main>
      <WordChallengeGame />
    </main>
  )
}

'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { QUESTIONS, type Question } from '@/lib/questions'
import {
  playCorrect,
  playTick,
  playTimeout,
  playVictory,
  playWrong,
} from '@/lib/sounds'

const ACCESS_CODE = '1234'
const MAX_TIME = 15
const WIN_SCORE = 100
const MIN_PLAYERS = 1
const MAX_PLAYERS = 5

type Phase = 'lock' | 'instructions' | 'playercount' | 'setup' | 'game'

export function WordChallengeGame() {
  const [phase, setPhase] = useState<Phase>('lock')

  // Lock screen
  const [codeInput, setCodeInput] = useState('')

  // Player count selection
  const [playerCount, setPlayerCount] = useState<number | null>(null)
  const [draftPlayerCount, setDraftPlayerCount] = useState<number>(2)

  // Player names and scores
  const [playerNames, setPlayerNames] = useState<string[]>(['اللاعب 1', 'اللاعب 2'])
  const [draftNames, setDraftNames] = useState<string[]>(['اللاعب 1', 'اللاعب 2'])
  const [scores, setScores] = useState<number[]>([0, 0])

  // Game state
  const [started, setStarted] = useState(false)
  const [turn, setTurn] = useState(0)
  const [question, setQuestion] = useState<Question | null>(null)
  const [timeLeft, setTimeLeft] = useState(MAX_TIME)
  const [winner, setWinner] = useState<string | null>(null)

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const usedRef = useRef<number[]>([])
  const advanceRef = useRef<() => void>(() => {})
  const scoresRef = useRef<number[]>([0, 0])

  useEffect(() => {
    scoresRef.current = scores
  }, [scores])

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current)
      timerRef.current = null
    }
  }, [])

  useEffect(() => stopTimer, [stopTimer])

  const pickQuestion = useCallback((): Question => {
    let available: number[] = []
    for (let i = 0; i < QUESTIONS.length; i++) {
      if (usedRef.current.indexOf(i) === -1) available.push(i)
    }
    if (available.length === 0) {
      usedRef.current = []
      available = QUESTIONS.map((_, i) => i)
    }
    const idx = available[Math.floor(Math.random() * available.length)]
    usedRef.current.push(idx)
    return QUESTIONS[idx]
  }, [])

  const startTimer = useCallback(() => {
    stopTimer()
    setTimeLeft(MAX_TIME)
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        const next = prev - 1
        if (next <= 5 && next > 0) playTick()
        if (next <= 0) {
          stopTimer()
          playTimeout()
          setTurn((t) => (t + 1) % (playerCount || 2))
          window.setTimeout(() => {
            alert('⏰ انتهى الوقت! الدور ينتقل للمنافس.')
            advanceRef.current()
          }, 0)
          return 0
        }
        return next
      })
    }, 1000)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stopTimer, playerCount])

  const advance = useCallback(() => {
    stopTimer()
    const maxScore = Math.max(...scoresRef.current)
    if (maxScore >= WIN_SCORE) {
      playVictory()
      const winnerIndex = scoresRef.current.indexOf(maxScore)
      setWinner(playerNames[winnerIndex])
      setStarted(false)
      setQuestion(null)
      // Reset to player count selection after 3 seconds
      window.setTimeout(() => {
        setPhase('playercount')
        setScores(Array(playerCount || 2).fill(0))
        setTurn(0)
        setWinner(null)
        usedRef.current = []
      }, 3000)
      return
    }
    setQuestion(pickQuestion())
    startTimer()
  }, [stopTimer, pickQuestion, startTimer, playerNames])

  useEffect(() => {
    advanceRef.current = advance
  }, [advance])

  const handleUnlock = useCallback(() => {
    if (codeInput === ACCESS_CODE) {
      setPhase('instructions')
    } else {
      alert('الكود غير صحيح! حاول مرة أخرى.')
    }
  }, [codeInput])

  const confirmPlayerCount = useCallback(() => {
    const count = Math.max(MIN_PLAYERS, Math.min(MAX_PLAYERS, draftPlayerCount))
    setPlayerCount(count)
    setPlayerNames(Array.from({ length: count }, (_, i) => `اللاعب ${i + 1}`))
    setDraftNames(Array.from({ length: count }, (_, i) => `اللاعب ${i + 1}`))
    setScores(Array(count).fill(0))
    setPhase('setup')
  }, [draftPlayerCount])

  const resetState = useCallback(() => {
    stopTimer()
    const count = playerCount || 2
    setScores(Array(count).fill(0))
    setTurn(0)
    setStarted(false)
    usedRef.current = []
    setQuestion(null)
    setWinner(null)
    setTimeLeft(MAX_TIME)
  }, [stopTimer, playerCount])

  const confirmNames = useCallback(() => {
    const validNames = draftNames.map((name, i) => name || `اللاعب ${i + 1}`)
    setPlayerNames(validNames)
    setPhase('game')
    resetState()
  }, [draftNames, resetState])

  const editNames = useCallback(() => {
    setDraftNames([...playerNames])
    setPhase('setup')
  }, [playerNames])

  const restartGame = useCallback(() => {
    stopTimer()
    setPhase('instructions')
    resetState()
    usedRef.current = []
  }, [stopTimer, resetState])

  const startGame = useCallback(() => {
    if (started) return
    setStarted(true)
    setWinner(null)
    usedRef.current = []
    setQuestion(pickQuestion())
    startTimer()
  }, [started, pickQuestion, startTimer])

  const judgeCorrect = useCallback(() => {
    stopTimer()
    playCorrect()
    const newScores = [...scores]
    newScores[turn] += 5
    setScores(newScores)
    setTurn((t) => (t + 1) % (playerCount || 2))
    window.setTimeout(advance, 0)
  }, [stopTimer, turn, scores, advance, playerCount])

  const judgeWrong = useCallback(() => {
    stopTimer()
    playWrong()
    setTurn((t) => (t + 1) % (playerCount || 2))
    window.setTimeout(advance, 0)
  }, [stopTimer, advance, playerCount])

  const turnName = playerNames[turn]
  const barPct = (timeLeft / MAX_TIME) * 100
  const barColor =
    timeLeft <= 5
      ? 'var(--color-red)'
      : timeLeft <= 10
        ? 'var(--color-orange)'
        : 'var(--color-green)'

  return (
    <div className="mx-auto my-[30px] max-w-[450px] rounded-[15px] bg-card p-[25px] shadow-[0_10px_25px_rgba(0,0,0,0.3)]">
      <h1 className="mt-0 mb-4 text-3xl font-bold text-yellow">🎮 حرف وتحدي</h1>

      {/* Lock section */}
      {phase === 'lock' && (
        <div>
          <div className="mb-[10px] text-[60px] leading-none">🔒</div>
          <div className="mb-[5px] text-2xl font-bold text-rose">
            اللعبة مقفلة
          </div>
          <div className="mb-5 text-sm text-muted">
            أدخل كود الدخول لبدء اللعبة
          </div>
          <Input
            type="password"
            value={codeInput}
            placeholder="أدخل الكود..."
            autoComplete="off"
            onChange={(e) => setCodeInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleUnlock()
            }}
          />
          <br />
          <PrimaryButton onClick={handleUnlock}>فتح اللعبة</PrimaryButton>
        </div>
      )}

      {/* Instructions section */}
      {phase === 'instructions' && (
        <div>
          <div className="mb-5 text-2xl font-bold text-yellow">
            📖 تعليمات اللعبة
          </div>
          <div className="mb-5 space-y-3 text-sm text-foreground">
            <div className="rounded-lg bg-panel p-3">
              <div className="font-bold text-accent">🎯 كيفية اللعب:</div>
              <div>تحدّ اللاعبين على الإجابة عن الأسئلة بسرعة ودقة</div>
            </div>
            <div className="rounded-lg bg-panel p-3">
              <div className="font-bold text-accent">👥 عدد اللاعبين:</div>
              <div>يمكن لعب اللعبة مع 1 إلى 5 لاعبين</div>
            </div>
            <div className="rounded-lg bg-panel p-3">
              <div className="font-bold text-accent">⏱️ الوقت:</div>
              <div>لكل لاعب 15 ثانية للإجابة عن السؤال</div>
            </div>
            <div className="rounded-lg bg-panel p-3">
              <div className="font-bold text-accent">⭐ النقاط:</div>
              <div>الإجابة الصحيحة = 5 نقاط</div>
            </div>
            <div className="rounded-lg bg-panel p-3">
              <div className="font-bold text-accent">🏆 الهدف:</div>
              <div>كن أول لاعب يصل إلى 100 نقطة!</div>
            </div>
            <div className="rounded-lg bg-panel p-3">
              <div className="font-bold text-accent">👨‍⚖️ دور الحكم:</div>
              <div>اضغط "صح" إذا كانت الإجابة صحيحة أو "خطأ" إذا كانت خاطئة</div>
            </div>
            <div className="rounded-lg bg-panel p-3">
              <div className="font-bold text-accent">📚 البنك السؤالي:</div>
              <div>أكثر من 2000 سؤال بمستويات مختلفة (سهل - متوسط - صعب)</div>
            </div>
          </div>
          <PrimaryButton onClick={() => setPhase('playercount')}>
            متابعة للعبة
          </PrimaryButton>
        </div>
      )}

      {/* Player count section */}
      {phase === 'playercount' && (
        <div>
          <div className="mb-5 text-xl font-bold text-accent">
            اختر عدد اللاعبين
          </div>
          <div className="mb-5 flex flex-col items-center gap-[15px]">
            <div className="flex flex-col items-center gap-[10px]">
              <label htmlFor="playercount" className="text-sm text-muted">
                عدد اللاعبين (1-5):
              </label>
              <div className="flex gap-[10px]">
                {[1, 2, 3, 4, 5].map((num) => (
                  <button
                    key={num}
                    onClick={() => setDraftPlayerCount(num)}
                    className={`h-[50px] w-[50px] cursor-pointer rounded-lg border-2 text-lg font-bold transition-colors ${
                      draftPlayerCount === num
                        ? 'border-accent bg-accent text-background'
                        : 'border-edge bg-panel text-foreground hover:border-accent'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <PrimaryButton onClick={confirmPlayerCount}>
            تأكيد عدد اللاعبين
          </PrimaryButton>
        </div>
      )}

      {/* Setup section */}
      {phase === 'setup' && (
        <div>
          <div className="mb-5 text-xl font-bold text-accent">
            أدخل أسماء اللاعبين
          </div>
          <div className="mb-5 flex flex-col gap-[15px]">
            {draftNames.map((name, i) => (
              <div key={i} className="flex flex-col items-center gap-[5px]">
                <label htmlFor={`player-${i}`} className="text-sm text-muted">
                  اللاعب {i + 1}:
                </label>
                <Input
                  id={`player-${i}`}
                  type="text"
                  className="w-4/5"
                  value={name}
                  placeholder={`اسم اللاعب ${i + 1}`}
                  onChange={(e) => {
                    const newNames = [...draftNames]
                    newNames[i] = e.target.value
                    setDraftNames(newNames)
                  }}
                />
              </div>
            ))}
          </div>
          <PrimaryButton onClick={confirmNames}>
            تأكيد الأسماء وبدء اللعبة
          </PrimaryButton>
        </div>
      )}

      {/* Game section */}
      {phase === 'game' && (
        <div>
          <div className="mb-[10px] rounded-lg bg-accent/10 p-[10px] text-[22px] font-bold text-accent">
            {started
              ? `دور: ${turnName}`
              : winner
                ? 'انتهت اللعبة'
                : 'اضغط "بدء اللعبة" للبدء'}
          </div>

          {/* Timer */}
          <div className="my-[15px] flex items-center justify-center gap-[10px]">
            <div className="h-3 w-[70%] overflow-hidden rounded-md bg-panel">
              <div
                className="h-full rounded-md transition-[width,background-color] duration-1000 ease-linear"
                style={{ width: `${barPct}%`, background: barColor }}
              />
            </div>
            <div className="min-w-[35px] text-xl font-bold text-accent">
              {timeLeft}
            </div>
          </div>

          {question && (
            <div
              className="mb-[10px] inline-block rounded-xl px-[10px] py-1 text-xs font-bold text-foreground"
              style={{ background: question.color }}
            >
              المستوى: {question.level}
            </div>
          )}

          <div className="my-[15px] flex min-h-[50px] items-center justify-center text-lg font-bold text-slate">
            {question ? question.q : 'استعد للتحدي!'}
          </div>

          <div className="mt-[10px] text-sm text-muted">
            الحرف الأول من الإجابة:
          </div>
          <div className="mx-auto my-[15px] flex h-[60px] w-[200px] items-center justify-center rounded-[10px] bg-panel-dark text-[40px] font-bold text-accent">
            {question ? question.hint : '?'}
          </div>

          {/* Answer reveal (for the referee) */}
          {question && started && (
            <div className="my-[15px] rounded-[10px] border-2 border-dashed border-green bg-green/10 p-[15px]">
              <div className="mb-[5px] text-sm text-muted">
                الإجابة الصحيحة:
              </div>
              <div className="text-2xl font-bold text-green">{question.a}</div>
            </div>
          )}

          {/* Judge buttons */}
          {question && started && (
            <div className="my-5">
              <div className="mb-[10px] text-base font-bold text-yellow">
                ⚖️ حكم الحكم:
              </div>
              <div className="flex justify-center gap-[15px]">
                <button
                  onClick={judgeCorrect}
                  className="mt-[15px] cursor-pointer rounded-lg border-none bg-green px-[25px] py-3 text-lg font-bold text-foreground transition-colors hover:bg-green-hover active:scale-[0.98]"
                >
                  ✅ صح
                </button>
                <button
                  onClick={judgeWrong}
                  className="mt-[15px] cursor-pointer rounded-lg border-none bg-red px-[25px] py-3 text-lg font-bold text-foreground transition-colors hover:bg-red-hover active:scale-[0.98]"
                >
                  ❌ خطأ
                </button>
              </div>
            </div>
          )}

          <br />
          {!started && (
            <PrimaryButton onClick={startGame}>
              {winner ? 'لعبة جديدة' : 'بدء اللعبة'}
            </PrimaryButton>
          )}
          <button
            onClick={resetState}
            className="mt-[15px] mr-[10px] w-[140px] cursor-pointer rounded-lg border-none bg-rose px-5 py-3 text-base font-bold text-foreground transition-colors hover:bg-rose-hover active:scale-[0.98]"
          >
            إعادة تعيين
          </button>
          <button
            onClick={editNames}
            className="mt-[15px] mr-[10px] cursor-pointer rounded-lg border-none bg-purple px-[15px] py-3 text-base font-bold text-foreground transition-colors hover:bg-purple-hover active:scale-[0.98]"
          >
            تغيير الأسماء
          </button>
          <button
            onClick={restartGame}
            className="mt-[15px] mr-[10px] cursor-pointer rounded-lg border-none bg-blue px-[15px] py-3 text-base font-bold text-foreground transition-colors hover:bg-blue-hover active:scale-[0.98]"
          >
            البدء من جديد
          </button>

          {winner && (
            <div className="animate-pop mt-[15px] text-2xl font-bold text-green">
              🎉 انتهت اللعبة بفوز {winner}!
            </div>
          )}

          <div className="mt-[25px] rounded-[10px] bg-panel p-[15px]">
            <div className="mb-[10px] text-sm font-bold text-muted">
              الدرجات:
            </div>
            <div className="flex flex-col gap-[10px]">
              {playerNames.map((name, i) => (
                <div
                  key={i}
                  className={`flex items-center justify-between rounded-lg p-[10px] ${
                    i === turn && started
                      ? 'bg-accent/20 ring-2 ring-accent'
                      : 'bg-panel-dark'
                  }`}
                >
                  <span className="font-semibold">{name}:</span>
                  <span className="text-lg font-bold text-accent">
                    {scores[i]}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function PrimaryButton({
  children,
  onClick,
}: {
  children: React.ReactNode
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="mt-[15px] h-auto min-w-[140px] cursor-pointer rounded-lg border-none bg-accent px-5 py-3 text-base font-bold text-background transition-colors hover:bg-accent-hover active:scale-[0.98]"
    >
      {children}
    </button>
  )
}

function Input({
  className = '',
  ...props
}: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`mt-[10px] w-[70%] rounded-lg border-2 border-edge bg-panel px-3 py-3 text-base text-foreground outline-none transition-colors focus:border-accent ${className}`}
    />
  )
}

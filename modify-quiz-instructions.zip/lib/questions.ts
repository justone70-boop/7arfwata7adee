import data from './questions.json'

export type Question = {
  q: string
  a: string
  hint: string
  level: string
  color: string
}

export const QUESTIONS = data as Question[]

// Web Audio sound effects, recreated from the original game.

let ctx: AudioContext | null = null

function getCtx(): AudioContext {
  if (!ctx) {
    const AudioCtor =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext
    ctx = new AudioCtor()
  }
  return ctx
}

// Correct answer: ascending C5 -> E5 -> G5 chime with a harmonic.
export function playCorrect() {
  const e = getCtx()
  const l = e.createOscillator()
  const o = e.createOscillator()
  const t = e.createGain()
  l.type = 'sine'
  l.frequency.setValueAtTime(523, e.currentTime)
  l.frequency.setValueAtTime(659, e.currentTime + 0.1)
  l.frequency.setValueAtTime(784, e.currentTime + 0.2)
  o.type = 'sine'
  o.frequency.setValueAtTime(523 * 1.5, e.currentTime)
  o.frequency.setValueAtTime(659 * 1.5, e.currentTime + 0.1)
  o.frequency.setValueAtTime(784 * 1.5, e.currentTime + 0.2)
  t.gain.setValueAtTime(0.2, e.currentTime)
  t.gain.exponentialRampToValueAtTime(0.01, e.currentTime + 0.4)
  l.connect(t)
  o.connect(t)
  t.connect(e.destination)
  l.start(e.currentTime)
  o.start(e.currentTime)
  l.stop(e.currentTime + 0.4)
  o.stop(e.currentTime + 0.4)
}

// Wrong answer: dramatic descending "sad trombone" with deeper tone.
export function playWrong() {
  const e = getCtx()
  const osc1 = e.createOscillator()
  const osc2 = e.createOscillator()
  const gain = e.createGain()
  
  osc1.type = 'sawtooth'
  osc1.frequency.setValueAtTime(300, e.currentTime)
  osc1.frequency.exponentialRampToValueAtTime(80, e.currentTime + 0.5)
  
  osc2.type = 'triangle'
  osc2.frequency.setValueAtTime(150, e.currentTime)
  osc2.frequency.exponentialRampToValueAtTime(40, e.currentTime + 0.5)
  
  gain.gain.setValueAtTime(0.3, e.currentTime)
  gain.gain.exponentialRampToValueAtTime(0.01, e.currentTime + 0.6)
  
  osc1.connect(gain)
  osc2.connect(gain)
  gain.connect(e.destination)
  
  osc1.start(e.currentTime)
  osc2.start(e.currentTime)
  osc1.stop(e.currentTime + 0.6)
  osc2.stop(e.currentTime + 0.6)
}

// Time's up: intense descending alarm with wobble effect.
export function playTimeout() {
  const e = getCtx()
  const l = e.createOscillator()
  const o = e.createOscillator()
  const t = e.createGain()
  l.type = 'square'
  l.frequency.setValueAtTime(800, e.currentTime)
  l.frequency.exponentialRampToValueAtTime(300, e.currentTime + 0.4)
  o.type = 'sine'
  o.frequency.setValueAtTime(12, e.currentTime)
  const s = e.createGain()
  o.connect(s)
  s.connect(l.frequency)
  s.gain.setValueAtTime(100, e.currentTime)
  t.gain.setValueAtTime(0.3, e.currentTime)
  t.gain.exponentialRampToValueAtTime(0.01, e.currentTime + 0.4)
  l.connect(t)
  t.connect(e.destination)
  l.start(e.currentTime)
  o.start(e.currentTime)
  l.stop(e.currentTime + 0.4)
  o.stop(e.currentTime + 0.4)
}

// Tick: short high beep during the danger window.
export function playTick() {
  const e = getCtx()
  const l = e.createOscillator()
  const o = e.createGain()
  l.type = 'sine'
  l.frequency.setValueAtTime(880, e.currentTime)
  o.gain.setValueAtTime(0.15, e.currentTime)
  o.gain.exponentialRampToValueAtTime(0.01, e.currentTime + 0.05)
  l.connect(o)
  o.connect(e.destination)
  l.start(e.currentTime)
  l.stop(e.currentTime + 0.05)
}

// Victory fanfare: epic ascending scale with harmonic layers.
export function playVictory() {
  const e = getCtx()
  const frequencies = [
    { freq: 523, harmonic: 1.5 },
    { freq: 659, harmonic: 2 },
    { freq: 784, harmonic: 2.5 },
    { freq: 1047, harmonic: 3 }
  ]
  
  frequencies.forEach((data, i) => {
    const mainOsc = e.createOscillator()
    const harmOsc = e.createOscillator()
    const gain = e.createGain()
    
    mainOsc.type = 'sine'
    mainOsc.frequency.setValueAtTime(data.freq, e.currentTime + i * 0.12)
    
    harmOsc.type = 'sine'
    harmOsc.frequency.setValueAtTime(data.freq * data.harmonic, e.currentTime + i * 0.12)
    
    gain.gain.setValueAtTime(0.25, e.currentTime + i * 0.12)
    gain.gain.exponentialRampToValueAtTime(0.01, e.currentTime + i * 0.12 + 0.4)
    
    mainOsc.connect(gain)
    harmOsc.connect(gain)
    gain.connect(e.destination)
    
    mainOsc.start(e.currentTime + i * 0.12)
    harmOsc.start(e.currentTime + i * 0.12)
    mainOsc.stop(e.currentTime + i * 0.12 + 0.4)
    harmOsc.stop(e.currentTime + i * 0.12 + 0.4)
  })
}
